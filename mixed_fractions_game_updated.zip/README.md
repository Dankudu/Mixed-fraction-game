# Mixed Fractions Game 🎮

Welcome to the **Mixed Fractions Game** created for **DAARUL-FURQAAN ACADEMY, Kaduna** 🎓.  
This simple game helps Grade 3 pupils practice solving **mixed fraction addition problems** in a fun and interactive way.

---

## 🌐 Play Online
👉 [Click here to play the game](https://yourusername.github.io/mixed-fractions-game/)  

*(Replace `yourusername` with your GitHub username after setting up GitHub Pages.)*

---

## 📖 How to Play
1. Click the **Start Game** button.  
2. Solve the mixed fraction problem displayed.  
3. Type your answer in the box (e.g., `3 1/2`).  
4. Click **Submit** to check if it’s correct.  
5. Your score will increase with each correct answer.  

---

## 🛠 Files in this Project
- `index.html` → The main page of the game  
- `style.css` → The design and layout  
- `script.js` → The game logic (random problems, checking answers, score tracking)  
- `README.md` → This file, explaining the project  

---

## 🎯 Target Audience
This project is designed for **Grade 3 pupils** to strengthen their understanding of **fractions** while having fun.  
