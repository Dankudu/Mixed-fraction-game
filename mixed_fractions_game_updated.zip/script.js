// Switch from cover page to game
document.getElementById("start-btn").addEventListener("click", () => {
  document.getElementById("cover-page").classList.add("hidden");
  document.getElementById("game-page").classList.remove("hidden");
  generateProblem();
});

let score = 0;

// Generate mixed fraction problem
function generateProblem() {
  const whole1 = Math.floor(Math.random() * 5) + 1;
  const num1 = Math.floor(Math.random() * 4) + 1;
  const den1 = Math.floor(Math.random() * 5) + 2;

  const whole2 = Math.floor(Math.random() * 5) + 1;
  const num2 = Math.floor(Math.random() * 4) + 1;
  const den2 = den1;

  document.getElementById("problem").innerText =
    `${whole1} ${num1}/${den1} + ${whole2} ${num2}/${den2}`;

  document.getElementById("problem").dataset.answer =
    simplifyFraction(
      (whole1 * den1 + num1) + (whole2 * den2 + num2),
      den1
    );
}

// Simplify fraction
function simplifyFraction(num, den) {
  function gcd(a, b) {
    return b === 0 ? a : gcd(b, a % b);
  }
  const divisor = gcd(num, den);
  num /= divisor;
  den /= divisor;

  const whole = Math.floor(num / den);
  const remainder = num % den;
  return remainder === 0 ? `${whole}` : `${whole} ${remainder}/${den}`;
}

// Check answer
document.getElementById("submit").addEventListener("click", () => {
  const userAnswer = document.getElementById("answer").value.trim();
  const correctAnswer = document.getElementById("problem").dataset.answer;

  if (userAnswer === correctAnswer) {
    document.getElementById("feedback").innerText = "✅ Correct!";
    score++;
  } else {
    document.getElementById("feedback").innerText =
      `❌ Incorrect. Correct answer: ${correctAnswer}`;
  }

  document.getElementById("score").innerText = "Score: " + score;
  document.getElementById("answer").value = "";
  generateProblem();
});
